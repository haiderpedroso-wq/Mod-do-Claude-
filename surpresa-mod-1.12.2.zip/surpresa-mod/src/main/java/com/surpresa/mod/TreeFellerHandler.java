package com.surpresa.mod;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import net.minecraft.block.BlockLog;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/** Quebrou um tronco com machado? A arvore inteira cai. Agachado = quebra normal. */
public class TreeFellerHandler {
    private static final int MAX_LOGS = 128;

    @SubscribeEvent
    public void onBreak(BlockEvent.BreakEvent event) {
        World world = event.getWorld();
        EntityPlayer player = event.getPlayer();
        if (world.isRemote || player == null || player.isSneaking()) return;

        ItemStack tool = player.getHeldItemMainhand();
        if (!(tool.getItem() instanceof ItemAxe)) return;
        if (!(event.getState().getBlock() instanceof BlockLog)) return;

        Set<BlockPos> visited = new HashSet<>();
        Deque<BlockPos> queue = new ArrayDeque<>();
        List<BlockPos> found = new ArrayList<>();
        visited.add(event.getPos());
        queue.add(event.getPos());

        while (!queue.isEmpty() && found.size() < MAX_LOGS) {
            BlockPos c = queue.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        BlockPos n = c.add(dx, dy, dz);
                        if (visited.add(n) && world.getBlockState(n).getBlock() instanceof BlockLog) {
                            found.add(n);
                            queue.add(n);
                        }
                    }
                }
            }
        }

        boolean creative = player.capabilities.isCreativeMode;
        for (BlockPos pos : found) {
            if (tool.isEmpty()) break;
            world.destroyBlock(pos, !creative);
            if (!creative) tool.damageItem(1, player);
        }
    }
}
